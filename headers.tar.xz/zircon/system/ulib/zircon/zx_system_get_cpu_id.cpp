// Copyright 2016 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <zircon/syscalls.h>

#include "private.h"

zx_status_t _zx_system_get_cpu_id(uint8_t *id, uint64_t hwid) {
    if (id == nullptr)
        return ZX_ERR_INVALID_ARGS;

    for (uint8_t i = 0; i < MAX_NUM_CPUS; i++) {
        if (DATA_CONSTANTS.cpu_hwid[i] == hwid) {
            *id = i;
            return ZX_OK;
        }
    }

    return ZX_ERR_NOT_FOUND;
}

VDSO_INTERFACE_FUNCTION(zx_system_get_cpu_id);
