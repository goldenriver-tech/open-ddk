// Copyright 2016 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <zircon/syscalls.h>

#include <zircon/compiler.h>
#include "private.h"

uint32_t _zx_system_get_tee_vendor_id(void) {
    return DATA_CONSTANTS.tee_vendor_id;
}

VDSO_INTERFACE_FUNCTION(zx_system_get_tee_vendor_id);
