// Copyright 2016 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <zircon/syscalls.h>

#include "private.h"

zx_status_t _zx_system_get_cpu_hwid(uint64_t* hwid, uint16_t id) {
    if (hwid == nullptr)
        return ZX_ERR_INVALID_ARGS;
    if (id >= DATA_CONSTANTS.max_num_cpus)
        return ZX_ERR_OUT_OF_RANGE;

    *hwid = DATA_CONSTANTS.cpu_hwid[id];
    return ZX_OK;
}

VDSO_INTERFACE_FUNCTION(zx_system_get_cpu_hwid);
