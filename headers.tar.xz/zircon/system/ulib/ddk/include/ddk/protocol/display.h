// Copyright 2016 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <zircon/compiler.h>
#include <zircon/types.h>
#include <zircon/pixelformat.h>
#include <zircon/device/display.h>

__BEGIN_CDECLS;

/**
 * protocol/display.h - display protocol definitions
 */

typedef void (*zx_display_cb_t)(bool acquired, void* cookie);

typedef struct display_protocol_ops {
    // sets the display mode
    zx_status_t (*set_mode)(void* ctx, zx_display_info_t* info);

    // gets the display mode
    zx_status_t (*get_mode)(void* ctx, zx_display_info_t* info);

    // gets a pointer to the framebuffer
    zx_status_t (*get_framebuffer)(void* ctx, void** framebuffer);

    // get framebuffer num
    uint32_t (*get_num_buffers)(void* ctx);

    // get multi pointer to the framebuffer
    zx_status_t (*get_multi_framebuffer)(void* ctx, uint32_t idx, void** framebuffer);

    // flushes the framebuffer
    void (*flush)(void* ctx);

    // Controls ownership of the display between multiple display clients.
    // Useful for switching to and from the gfxconsole.
    // If the framebuffer is visible, release ownership of the display and
    // allow other clients to scanout buffers.
    // If the framebuffer is not visible, make it visible and acquire ownership
    // of the display, preventing other clients from scanning out buffers.
    // If the display is owned when when a new graphics client is created,
    // ownership will automatically be released.
    void (*acquire_or_release_display)(void* ctx, bool acquire);

    // Registers a callback to be invoked when display ownership changes.
    // The provided callback will be invoked with a value of true if the display
    // has been acquired, false if it has been released.
    void (*set_ownership_change_callback)(void* ctx, zx_display_cb_t callback, void* cookie);
} display_protocol_ops_t;

typedef struct zx_display_protocol {
    display_protocol_ops_t* ops;
    void* ctx;
} display_protocol_t;
__END_CDECLS;
