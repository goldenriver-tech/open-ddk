// Copyright 2024 The GoldenRiverTek Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

__BEGIN_CDECLS;

typedef struct wdt_protocol_ops {
    zx_status_t (*wdt_start)(void* ctx);
    zx_status_t (*wdt_stop)(void* ctx);
    zx_status_t (*wdt_ping)(void* ctx);
    zx_status_t (*wdt_set_timeout)(void* ctx, unsigned int timeout);
} wdt_protocol_ops_t;

typedef struct wdt_protocol {
    wdt_protocol_ops_t* ops;
    void* ctx;
} wdt_protocol_t;

__END_CDECLS;
