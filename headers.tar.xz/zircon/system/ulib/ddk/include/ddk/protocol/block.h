// Copyright 2017 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <assert.h>
#include <stdint.h>
#include <zircon/device/block.h>
#include <zircon/device/blk_crypto.h>

// block_op_t's are submitted for processing via the queue() method
// of the block_protocol.  Once submitted, the contents of the block_op_t
// may be modified while it's being processed and/or as it is passed down
// the stack to lower layered drivers.
//
// The contents may be mutated along the way -- for example, a partition
// driver would, after validation, adjust offset_dev to reflect the position
// of the partition.
//
// The completion_cb() must eventually be called upon success or failure and
// at that point the cookie field must contain whatever value was in it when
// the block_op_t was originally queued.
//
// The rw.pages field may be modified but the *contents* of the array it points
// to may not be modified.

typedef struct block_op block_op_t;

struct phys_region {
  uint64_t phys_addr;
  uint32_t len;
};

#define UIO_MAXVEC 1

struct block_op {
  uint32_t command; // command and flags
  union {
    // BLOCK_OP_READ, BLOCK_OP_WRITE
    struct {
      uint32_t extra;  // available for temporary use
      zx_handle_t vmo; // vmo of data to read or write
      bool cache_flushed;
      union {
        struct {
          uint64_t offset_vmo; // vmo offset in blocks
          uint32_t length;     // transfer length in blocks (0 is invalid)
        };
        struct phys_region vecs[UIO_MAXVEC];
      };
      uint64_t offset_dev; // device offset in blocks
      uint64_t *pages;     // optional physical page list
      uint64_t sector;
      uint64_t sectors;
      uint64_t vmo_off;
      uint64_t vm;
      struct bio_crypt_ctx *crypto_context;
    } rw;

    // BLOCK_OP_DISCARD, BLOCK_OP_SECURE_ERASE, BLOCK_OP_WRITE_ZEROES,
    struct {
      uint64_t offset_dev; // device offset in blocks
      uint32_t length;     // process length in blocks (0 is invalid)
      uint64_t sector;
      uint64_t sectors;
      uint32_t flags;
      uint64_t vm;
    } erase;
  };

  // The completion_cb() will be called when the block operation
  // succeeds or fails, and cookie will be whatever was set when
  // the block_op was initially queue()'d.
  void (*completion_cb)(block_op_t *block, zx_status_t status);
  void *cookie;
};

#define block_op_crypto_ctx(bop) (bop->rw.crypto_context)
#define block_op_crypto_keyslot(bop) (block_op_crypto_ctx(bop)->keyslot)
#define block_op_crypto_key(bop) (block_op_crypto_ctx(bop)->bc_key)
#define block_op_crypto_dun(bop) (block_op_crypto_ctx(bop)->bc_dun)

typedef struct block_protocol_ops {
  // Obtain the parameters of the block device (block_info_t) and
  // the required size of block_txn_t.  The block_txn_t's submitted
  // via queue() must have block_op_size_out - sizeof(block_op_t) bytes
  // available at the end of the structure for the use of the driver.
  void (*query)(void *ctx, block_info_t *info_out, size_t *block_op_size_out);

  // Submit an IO request for processing.  Success or failure will
  // be reported via the completion_cb() in the block_op_t.  This
  // callback may be called before the queue() method returns.
  void (*queue)(void *ctx, block_op_t *txn);

  // define a struct blk_crypto_profile_dev in your own structure,
  // and use it to initialize struct blk_crypto_profile.
  struct blk_crypto_profile *crypto_profile;
} block_protocol_ops_t;

typedef struct block_protocol {
  block_protocol_ops_t *ops;
  void *ctx;
} block_protocol_t;

// Read and Write ops use u.rw for parameters.
//
// If u.rw.pages is not NULL, the VMO is already appropriately pinned
// for IO and pages is an array of the physical addresses covering
// offset_vmo * block_size through (offset_vmo + length + 1U) * block_size.
//
// The number of entries in this array is always
// ((u.rw.length + 1U * block_size + PAGE_SIZE - 1) / PAGE_SIZE)
#define BLOCK_OP_READ 0x00000001
#define BLOCK_OP_WRITE 0x00000002

// Write any controller or device cached data to nonvolatile storage.
// This operation always implies BARRIER_BEFORE and BARRIER_AFTER,
// meaning that previous operations will complete before it starts
// and later operations will not start until it is done.
#define BLOCK_OP_FLUSH 0x00000003
#define BLOCK_OP_DISCARD 0x00000004
#define BLOCK_OP_SECURE_ERASE 0x00000005
#define BLOCK_OP_WRITE_ZEROES 0x00000006

#define BLOCK_OP_MASK 0x000000FF


#ifndef __maybe_unused
#define __maybe_unused __attribute__((unused))
#endif
static __maybe_unused char const *block_op_str(uint8_t opcode) {
  uint8_t const op = BLOCK_OP_MASK & opcode;
  switch (op) {
  case BLOCK_OP_READ:
    return "read";
  case BLOCK_OP_WRITE:
    return "write";
  case BLOCK_OP_FLUSH:
    return "flush";
  case BLOCK_OP_DISCARD:
    return "discard";
  case BLOCK_OP_SECURE_ERASE:
    return "secure erase";
  case BLOCK_OP_WRITE_ZEROES:
    return "write zeroes";
  default:
    return "Unknown";
  }

  return NULL;
}

static __maybe_unused inline void dump_bop(struct block_op *bop) {
  uint8_t const opcode = bop->command & BLOCK_OP_MASK;
  printf("############ nebula dump bop ##############\n");
  printf("command: %s\n", block_op_str(opcode));
  if (opcode == BLOCK_OP_READ || opcode == BLOCK_OP_WRITE) {
    printf("bop->rw.sectors: %lu\n", bop->rw.sectors);
    printf("bop->rw.len: %lu\n", (uint64_t)bop->rw.length);
    printf("bop->rw.vm: 0x%lx\n", bop->rw.vm);
    printf("bop->rw.vmo_off: 0x%lx\n", bop->rw.vmo_off);
    printf("bop->rw.vmo_off_bz: 0x%lx\n", bop->rw.offset_vmo);
    printf("bop->rw.sector: %lu\n", bop->rw.sector);
    printf("bop->rw.blk_off: %lu\n", bop->rw.offset_dev);
  } else if (opcode == BLOCK_OP_DISCARD || opcode == BLOCK_OP_SECURE_ERASE ||
             opcode == BLOCK_OP_WRITE_ZEROES) {
    printf("bop->erase.offset_dev: %lu\n", bop->erase.offset_dev);
    printf("bop->erase.length: %lu\n", (uint64_t)bop->erase.length);
    printf("bop->erase.flags: 0x%x\n", bop->erase.flags);
    printf("bop->erase.vm: 0x%lx\n", bop->erase.vm);
  }
  printf("bop->cookie: 0x%lx\n", (unsigned long)bop->cookie);
}

#undef __maybe_unused

// Mark this operation as "Force Unit Access" (FUA), indicating that
// it should not complete until the data is written to the non-volatile
// medium (write), and that reads should bypass any on-device caches.
#define BLOCK_FL_FORCE_ACCESS 0x00001000

// Require that this operation will not begin until all previous
// operations have completed.
//
// Prevents earlier operations from being reordered after this one.
#define BLOCK_FL_BARRIER_BEFORE 0x00000100

// Require that this operation complete before any subsequent
// operations are started.
//
// Prevents later operations from being reordered before this one.
#define BLOCK_FL_BARRIER_AFTER 0x00000200
