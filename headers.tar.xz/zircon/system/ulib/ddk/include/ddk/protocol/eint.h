// Copyright 2026 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <zircon/compiler.h>
#include <zircon/types.h>

__BEGIN_CDECLS;

/**
 * protocol/eint.h - external interrupt protocol definitions
 */

typedef void (*eint_irq_handler_t)(void* ctx, uint32_t eint_num, uint32_t* is_forward);

typedef struct eint_protocol_ops {
    zx_status_t (*register_irq)(void* ctx, uint32_t eint_num, uint32_t type,
                                eint_irq_handler_t handler, void* handler_ctx);
    zx_status_t (*unregister_irq)(void* ctx, uint32_t eint_num);
} eint_protocol_ops_t;

typedef struct eint_protocol {
    eint_protocol_ops_t* ops;
    void* ctx;
} eint_protocol_t;

static inline zx_status_t eint_register_irq(eint_protocol_t* eint, uint32_t eint_num,
                                            uint32_t type, eint_irq_handler_t handler,
                                            void* handler_ctx) {
    return eint->ops->register_irq(eint->ctx, eint_num, type, handler, handler_ctx);
}

static inline zx_status_t eint_unregister_irq(eint_protocol_t* eint, uint32_t eint_num) {
    return eint->ops->unregister_irq(eint->ctx, eint_num);
}

__END_CDECLS;
