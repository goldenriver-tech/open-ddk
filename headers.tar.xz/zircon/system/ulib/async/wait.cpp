// Copyright 2017 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <lib/async/cpp/wait.h>

namespace async {

Wait::Wait(zx_handle_t object, zx_signals_t trigger, uint32_t flags)
    : async_wait_t{{ASYNC_STATE_INIT}, &Wait::CallHandler, object, trigger, flags, {}} {}

Wait::~Wait() {
  async_t* async = this->async_;
  (void)Cancel(async);
  ZX_DEBUG_ASSERT(!is_pending());
};

zx_status_t Wait::Begin(async_t* async) {
  if (async_)
    return ZX_ERR_ALREADY_EXISTS;

  async_ = async;
  zx_status_t status = async_begin_wait(async, this);
  if (status != ZX_OK) {
    async_ = nullptr;
  }
  return status;
}

zx_status_t Wait::Cancel(async_t* async) {
  if (!async_) {
    return ZX_ERR_NOT_FOUND;
  }

  if (async != async_)
    return ZX_ERR_INVALID_ARGS;

  async_ = nullptr;

  zx_status_t status = async_cancel_wait(async, this);
  // |dispatcher| is required to be single-threaded, Cancel() is
  // only supposed to be called on |dispatcher|'s thread, and
  // we verified that the wait was pending before calling
  // async_cancel_wait(). Assuming that |dispatcher| never queues
  // a wait, |wait_| must have been pending with |dispatcher|.
  ZX_DEBUG_ASSERT(status != ZX_ERR_NOT_FOUND);
  return status;
}

async_wait_result_t Wait::CallHandler(async_t* async, async_wait_t* wait,
                                      zx_status_t status, const zx_packet_signal_t* signal) {
    auto self = reinterpret_cast<Wait*>(wait);
    self->async_ = nullptr;
    return self->handler_(async, status, signal);
}

} // namespace async
