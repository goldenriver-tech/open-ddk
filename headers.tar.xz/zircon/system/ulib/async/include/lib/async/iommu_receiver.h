#pragma once

#include <lib/async/dispatcher.h>

__BEGIN_CDECLS

// Handles an asyncronous trap access.
typedef void (*async_iommu_event_handler_t)(async_t* async,
                                            async_iommu_receiver_t* receiver,
                                            const zx_packet_iommu_event_t* packet);

struct async_iommu_receiver {
    // Private state owned by the dispatcher, initialize to zero with |ASYNC_STATE_INIT|.
    async_state_t state;
    // The handler to invoke to handle the trap access.
    async_iommu_event_handler_t handler;
    // The receiver will get events from the iommu object.
    zx_handle_t iommu;
};

inline zx_status_t async_set_iommu_receiver(async_t* async, async_iommu_receiver_t* receiver) {
    return async->ops->set_iommu_receiver(async, receiver);
}

__END_CDECLS