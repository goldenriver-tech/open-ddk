// Copyright 2024 GoldenRiver Inc.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <lib/async/dispatcher.h>
#include <lib/async/iommu_receiver.h>
#include <fbl/function.h>
#include <fbl/macros.h>

namespace async {

// C++ wrapper for an async iommu receiver.
template <class Class,
          void (Class::*method)(async_t* async, const zx_packet_iommu_event_t* event)>
class IommuReceiverMethod : private async_iommu_receiver_t {
public:
    explicit IommuReceiverMethod(Class* ptr,
                                 zx_handle_t iommu = ZX_HANDLE_INVALID)
        : async_iommu_receiver_t{{ASYNC_STATE_INIT}, &IommuReceiverMethod::CallHandler,
                                  iommu},
          ptr_(ptr) {}

    // The iommu to receive events from
    zx_handle_t iommu() const { return async_iommu_receiver_t::iommu; }
    void set_iommu(zx_handle_t iommu) { async_iommu_receiver_t::iommu = iommu; }

    zx_status_t Begin(async_t* async) {
        return async_set_iommu_receiver(async, this);
    }

private:
    static void CallHandler(async_t* async, async_iommu_receiver_t* receiver,
                            const zx_packet_iommu_event_t* event) {
        return (static_cast<IommuReceiverMethod*>(receiver)->ptr_->*method)(async, event);
    }

    Class* const ptr_;

    DISALLOW_COPY_ASSIGN_AND_MOVE(IommuReceiverMethod);
};

} // namespace async