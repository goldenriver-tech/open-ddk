// Copyright 2018 GoldenRiver Technology Co., Ltd.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>

enum {
    SCBUF_WAIT_STARTUP_EVENT,
    SCBUF_MAP_HANDLE,
    SCBUF_UNMAP,
    SCBUF_OPEN,
    SCBUF_CLOSE,

    // for benchmark only
    SCBUF_CREATE_TEST_VMO,
    SCBUF_CLEAR_TEST_VMO_LIST,
    SCBUF_GENERATE_TEST_SGLIST,
    SCBUF_MAP_TEST_SGLIST,

    SCBUF_UNDEFINE = 65535
};

struct scbuf_info {
    uint32_t handle;
    void* vaddr;
    size_t size;
};
