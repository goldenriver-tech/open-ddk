// Copyright 2018 GoldenRiver Technology Co., Ltd.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>

enum {
    MOCK_RES_MGR_OPEN,
    MOCK_RES_MGR_CLOSE,
    MOCK_RES_MGR_ADD_VMO,
    MOCK_RES_MGR_UNDEFINE = 65535
};

static constexpr uint kKernelUnittestHandleId = 0;
static constexpr uint kUserUnittestHandleId = 1;
