// Copyright 2018 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <zircon/compiler.h>
#include <zircon/boot/bootdata.h>
#include <stdint.h>

// BOOTDATA_KERNEL_DRIVER bootdata types
#define KDRV_ARM_PSCI           0x49435350  // 'PSCI'
#define KDRV_ARM_GIC_V2         0x32434947  // 'GIC2'
#define KDRV_ARM_GIC_V3         0x33434947  // 'GIC3'
#define KDRV_ARM_SMMU_V3        0x4D4D5533  // 'SMMUV3'
#define KDRV_ARM_GENERIC_TIMER  0x4D495441  // 'ATIM'
#define KDRV_PL011_UART         0x55304C50  // 'PL0U'
#define KDRV_AMLOGIC_UART       0x554C4D41  // 'AMLU'
#define KDRV_NXP_IMX_UART       0x55584D49  // 'IMXU'
#define KDRV_MT8167_UART        0x5538544D  // 'MT8U'
#define KDRV_HISILICON_POWER    0x4F505348  // 'HSPO'
#define KDRV_AMLOGIC_HDCP       0x484C4D41  // 'AMLH'
#define KDRV_HYP_VTTY           0x56545459  // 'VTTY'
#define KDRV_HYP_VIRQ           0x51524956  // 'VIRQ'
#define KDRV_HYP_SBUF           0x46554253  // 'SBUF'
#define KDRV_HYP_SCBUF          0x46424353  // 'SCBF'
#define KDRV_HYP_RPMB           0x424D5052  // 'RPMB'
#define KDRV_HYP_NSS            0x53534E48  // 'HNSS'
#define KDRV_HYP_EMU_PIPE       0x50495045  // 'EPIP'
#define KDRV_HYP_MOCK_RES_MGR   0x4d524553  // 'MRES'
#define KDRV_SCHED_POLICY       0x45484353  // 'SCHE'
#define KDRV_VCPU_PHYP          0x59485056  // 'VPHY'
#define KDRV_NS16550A_UART      0x4130354E  // 'N50A'
#define KDRV_MTK_UART           0x554B544D  // 'MTKU'

// kernel driver struct that can be used for simple drivers
// used by KDRV_PL011_UART, KDRV_AMLOGIC_UART
typedef struct {
    uint64_t mmio_phys;
    uint32_t irq;
} dcfg_simple_t;

// for KDRV_MT8167_UART
typedef struct {
    uint64_t soc_mmio_phys;
    uint64_t uart_mmio_phys;
    uint32_t irq;
} dcfg_soc_uart_t;

// for KDRV_NXP_IMX_UART and KDRV_NXP_IMX_LPUART
typedef struct {
    uint64_t mmio_phys;
    uint32_t irq;
    uint32_t is_lp;
} dcfg_nxp_uart_t;

// for KDRV_ARM_PSCI
typedef struct {
    bool use_hvc;
    uint64_t shutdown_args[3];
    uint64_t reboot_args[3];
    uint64_t reboot_bootloader_args[3];
    uint64_t reboot_recovery_args[3];
} dcfg_arm_psci_driver_t;

// for KDRV_ARM_GIC_V2
typedef struct {
    uint64_t mmio_phys;
    uint64_t msi_frame_phys;
    uint64_t gicd_offset;
    uint64_t gicc_offset;
    uint64_t gich_offset;
    uint64_t gicv_offset;
    uint32_t ipi_generic;
    uint32_t ipi_reschedule;
    uint32_t ipi_interrupt;
    uint32_t ipi_halt;
    bool ipi_disabled;
    bool optional;
    bool use_msi;
} dcfg_arm_gicv2_driver_t;

// for KDRV_ARM_GIC_V3
typedef struct {
    uint64_t mmio_phys;
    uint64_t gicd_offset;
    uint64_t gicr_offset;
    uint64_t gicr_stride;
    uint64_t mx8_gpr_phys;
    uint32_t ipi_generic;
    uint32_t ipi_reschedule;
    uint32_t ipi_interrupt;
    uint32_t ipi_halt;
    bool ipi_disabled;
    bool optional;
} dcfg_arm_gicv3_driver_t;

// for KDRV_ARM_SMMU_V3
typedef struct {
    uint64_t mmio_phys;
    uint64_t mmio_size;
    uint64_t wp_mmio_phys;
    uint32_t evtq_irq;
    uint32_t priq_irq;
    uint32_t cmdq_sync_irq;
    uint32_t serror_irq;
} dcfg_arm_smmuv3_driver_t;

// for KDRV_ARM_GENERIC_TIMER
typedef struct {
    uint32_t irq_phys;
    uint32_t irq_virt;
    uint32_t irq_sphys;
    uint32_t freq_override;
} dcfg_arm_generic_timer_driver_t;

// for KDRV_HISILICON_POWER
typedef struct {
    uint64_t sctrl_phys;
    uint64_t pmu_phys;
} dcfg_hisilicon_power_driver_t;

// for KDRV_AMLOGIC_HDCP
typedef struct {
    uint64_t preset_phys;
    uint64_t hiu_phys;
    uint64_t hdmitx_phys;
} dcfg_amlogic_hdcp_driver_t;

struct dcfg_hyp_link_pipe {
    uint32_t tx_irq;
    uint32_t rx_irq;
    uint32_t tx_kcap;
    uint32_t rx_kcap;
    uint32_t use_default_scbuf;
};

// for KDRV_HYP_VTTY
typedef struct dcfg_hyp_link_pipe dcfg_hyp_vtty_driver_t;

// for KDRV_HYP_SCBUF
typedef struct dcfg_hyp_link_pipe dcfg_hyp_scbuf_driver_t;

// for KDRV_HYP_MOCK_RES_MGR
typedef struct dcfg_hyp_link_pipe dcfg_hyp_mock_res_mgr_t;

// for KDRV_HYP_EMU_PIPE
typedef struct {
    uint32_t kcap;
    uint32_t tx_irq;
    uint32_t rx_irq;
} dcfg_hyp_emu_pipe_t;

// User-level driver metadata
#define LINK_SHBUF_METADATA    (0x12e17800 | BOOTDATA_KIND_METADATA)

// for LINK_SHBUF_METADATA
enum {
    LINK_SHBUF_TYPE_GENERIC = 0,
    LINK_SHBUF_TYPE_TEST = 1,
    LINK_SHBUF_TYPE_BLOCK = 2,
};

typedef struct {
    // Device info
    char name[32];
    uint32_t type;
    // Outgoing virq
    uint32_t virqline;
    // Incoming virq
    uint32_t virq;
    // Shared memory
    uint64_t paddr;
    uint64_t size;
    uint32_t rwx;
} link_shbuf_info_t;

#define VS_SHBUF_METADATA    (0x12e17900 | BOOTDATA_KIND_METADATA)

typedef struct {
    uint64_t paddr;
    uint64_t size;
    uint32_t rwx;
    uint32_t notify_bits;
    uint32_t batch_size;
} vs_buf_params_t;

typedef struct {
    // Device info
    char name[32];
    // Outgoing virq
    uint32_t virqline;
    // Incoming virq
    uint32_t virq;
    // Shared memory
    vs_buf_params_t tx_buf;
    vs_buf_params_t rx_buf;
    uint32_t queue_length;
    uint32_t message_size;
    bool is_client;
} vs_shbuf_info_t;

#define LINK_PIPE_METADATA    (0x12e17A00 | BOOTDATA_KIND_METADATA)

typedef struct {
    char name[32];
    uint32_t tx_irq;
    uint32_t rx_irq;
    uint32_t tx_kcap;
    uint32_t rx_kcap;
} link_pipe_info_t;

#define HYP_VIRQ_METADATA     (0x12e17b00 | BOOTDATA_KIND_METADATA)

typedef struct {
    char name[32];
    uint32_t virq;
    uint32_t virqline;
} hyp_virq_info_t;

// for KDRV_HYP_RPMB
typedef struct {
    uint32_t base; /* in bytes */
    uint32_t size; /* in bytes */
    uint32_t programmed;
} dcfg_hyp_rpmb_t;

/**
 * About how to save the HAs.
 */
typedef enum {
    // Save HA in security storage.
    // - It's slowly, but it's more safe.
    SAVE_HA_BY_SS = 1,
    // Save HA in Non-Security storage,
    // - but cipher key, hash code, IV of HA are saved in security storage.
    SAVE_HA_BY_NSS = 2,
} SaveHaType;

enum {
    NBL_SYS_INFO_SHMTYPE_INVALID = 0,
    NBL_SYS_INFO_SHMTYPE_TIPC = 1,
    NBL_SYS_INFO_SHMTYPE_LINKBUF,
    NBL_SYS_INFO_SHMTYPE_HANDLECHN,
};

// for KDRV_HYP_NSS
typedef struct {
    uint32_t save_type;
    uint32_t shm_type;
} dcfg_hyp_nss_t;

// for KDRV_SCHED_POLICY
typedef struct {
    uint32_t use_trusty;
    uint32_t use_okl4_psci;
} dcfg_sched_policy_t;

// for KDRV_VCPU_PHYP
typedef struct {
    uint64_t os_entry_pa;
    uint64_t dtb_pa;
    uint64_t guest_mem_base;
    uint64_t guest_mem_size;
    uint32_t hcr;
} dcfg_vcpu_phyp_t;
