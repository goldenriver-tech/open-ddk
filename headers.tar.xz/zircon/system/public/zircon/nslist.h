// Copyright 2018 GoldenRiver Technologies Co., Ltd. All rights reserved.
//
// The present software is the confidential and proprietary information of
// GoldenRiver Technologies Co., Ltd. You shall not disclose the present
// software and shall use it only in accordance with the terms of the license
// agreement you entered into with GoldenRiver Technologies Co., Ltd.
// This software may be subject to export or import laws in certain countries.

#pragma once

#include <stdbool.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * non-intrusive single-linked list container like STL.
 * The pointer of end node of list is NULL.
 * The header of node MUST not keep the data, because it's will removed.
 */

/**
 * HEADER of list.
 * And it's used as node type of list.
 * If header's next are NULL, the list is empty.
 */
typedef struct nslist {
    struct nslist* next;
    void* data;
} nslist_t;

/**
 * The function for clear.
 * The prototype is same with free().
 */
typedef void (*nslist_free_func)(void* data);

/**
 * Initialize a list on list is a static global variable.
 */
#define LIST_INITIAL_VALUE \
    { .next = NULL, .data = NULL }

/**
 * Initialize a list.
 * Cannot used to clear a list.
 */
static inline void nslist_init(nslist_t* list) {
    list->next = NULL;
    list->data = NULL; // Cannot save data in list header.
}

static inline bool nslist_is_empty(nslist_t* list) {
    return (list->next == NULL) ? true : false;
}

static inline size_t nslist_length(nslist_t* list) {
    size_t cnt = 0;
    nslist_t* p;

    for (p = list; p->next != NULL; p = p->next) {
        cnt++;
    }

    return cnt;
}

static inline void* nslist_index_of(nslist_t* list, size_t index) {
    nslist_t* p;
    void* found = NULL;

    for (p = list->next; p != NULL; p = p->next, index--) {
        if (!index) {
            found = p->data;
            break;
        }
    }

    return found;
}

/**
 * Find the obj by pointer.
 * @return 0~: is index, -1: don't find.
 */
static inline int nslist_find(nslist_t* list, void* data) {
    nslist_t* p;
    int i;

    for (i = 0, p = list->next; p != NULL; p = p->next, i++) {
        if (p->data == data) {
            return i;
        }
    }

    return -1;
}

/**
 * Add a object at header.
 */
static inline bool nslist_add_head(nslist_t* list, void* item) {
    nslist_t* n;
    n = (nslist_t*)malloc(sizeof(nslist_t));
    if (!n)
        return false;

    n->data = item;
    n->next = list->next;
    list->next = n;

    return true;
}

/**
 * Add a object at tail.
 */
static inline bool nslist_add_tail(nslist_t* list, void* item) {
    nslist_t *p, *n;

    // find the last node.
    for (p = list; p->next != NULL; p = p->next) {
    }

    n = (nslist_t*)malloc(sizeof(nslist_t));
    if (!n)
        return false;

    p->next = n;
    n->next = NULL;
    n->data = item;

    return true;
}

/**
 * Remove the obj from begin of list.
 * @return inserted data.
 */
static inline void* nslist_remove_head(nslist_t* list) {
    nslist_t* p;
    void* data;

    if (!list->next) {
        return NULL;
    }

    p = list->next;
    list->next = p->next;

    data = p->data;
    free(p);
    return data;
}

static inline void* nslist_remove_tail(nslist_t* list) {
    nslist_t *p, *prev;
    void* data;

    // find the last node.
    for (prev = list, p = list; p->next != NULL; prev = p, p = p->next) {
    }

    // list is empty.
    if (p == list) {
        return NULL;
    }

    prev->next = NULL;

    data = p->data;
    free(p);
    return data;
}

/**
 * Clear the all list, and invoke free_func to free the data.
 * If free_func is NULL, will invoke nothing.
 * User can set free() as free_func.
 */
static inline void nslist_clear(nslist_t* list, nslist_free_func free_func) {
    void* data;

    while ((data = nslist_remove_tail(list))) {
        if (free_func) {
            free_func(data);
        }
    }
}

#ifdef __cplusplus
}
#endif
