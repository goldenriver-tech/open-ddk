// Copyright 2024 The GoldenRiverTek Authors
//
// Use of this source code is governed by a MIT-style
// license that can be found in the LICENSE file or at
// https://opensource.org/licenses/MIT

#pragma once

#include <zircon/nbl_trace/nbl_trace.h>

#define EVENT_NAME_LEN_MAX  32
#define TRACE_EVENT_CNT     32
#define KTRACE_META_LEN             65536

// default 64MiB
#define NBL_KTRACE_BUF_SIZE_DEFAULT (64 * 1024 * 1024)
#define NBL_KTRACE_BUF_SIZE_MIN (16 * 1024 * 1024)

enum {
    ////////////////////////// KTRACE start
    TRACE_EVENT_ID_IRQ,
    TRACE_EVENT_ID_SCHED,
    TRACE_EVENT_ID_KTRACE_END,
    ////////////////////////// KTRACE end
    ///////////////////////////////////////
    ////////////////////////// UTRACE start
    TRACE_EVENT_ID_FBEND = TRACE_EVENT_ID_KTRACE_END,
    TRACE_EVENT_ID_POWER,
    TRACE_EVENT_ID_UTRACE_END,
    ////////////////////////// UTRACE end
    TRACE_EVENT_ID_MAX = TRACE_EVENT_ID_UTRACE_END,
};

#define KTRACE_EVENT_MASK   BIT_MASK(TRACE_EVENT_ID_KTRACE_END)
#define UTRACE_EVENT_MASK \
    (BIT_MASK(TRACE_EVENT_ID_UTRACE_END) & ~KTRACE_EVENT_MASK)
#define TRACE_EVENT_MASK_ALL    (KTRACE_EVENT_MASK | UTRACE_EVENT_MASK)

typedef struct ktrace_events {
    const char* name;
    uint32_t group;
} ktrace_events_t;
