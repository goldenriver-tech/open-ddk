// Copyright 2024 The GoldenRiverTek Authors
//
// Use of this source code is governed by a MIT-style
// license that can be found in the LICENSE file or at
// https://opensource.org/licenses/MIT

#pragma once

#define BIT_MASK(x) (((x) >= sizeof(unsigned long) * 8) ? (0UL-1) : ((1UL << (x)) - 1))
#define _BIT(x)                     (1 << (x))
#define MASK_FLOOR(x)               (_BIT(x) - 1)
#define MASK_CEIL(x)                (~MASK_FLOOR(x))

#define ID_EVENT_SHFT               GRP_TYPE_CNT
#define NT_GROUP_MASK               BIT_MASK(ID_EVENT_SHFT)
#define NT_GROUP(tag)               ((tag) & NT_GROUP_MASK)
#define NT_EVENT(tag)               (((tag) & ~NT_GROUP_MASK) >> ID_EVENT_SHFT)

#define NT_TAG(group, event)        (((event) << ID_EVENT_SHFT) | (group))

// group definition
enum trace_groups {
    GRP_VCPU_EXEC,
    GRP_VCPU_RUN_ACCUM,
    GRP_VCPU_EXIT_REASON,
    GRP_IRQ_COUNT,
    GRP_PCPU_STATUS,
    GRP_VCPU_SCHED_DELAY,
    GRP_VCPU_EXEC_SPLIT,
    GRP_TOP,
    GRP_IRQ_DELAY,
    GRP_KTRACE,
    GRP_COMCAT_LINK,
    GRP_CPU_IPI_DELAY,
    GRP_NBL_REV,
    GRP_TYPE_CNT,
};

#define TAG_VCPU_EXEC               _BIT(GRP_VCPU_EXEC)
#define TAG_VCPU_RUN_ACCUM          _BIT(GRP_VCPU_RUN_ACCUM)
#define TAG_VCPU_EXIT_REASON        _BIT(GRP_VCPU_EXIT_REASON)
#define TAG_IRQ_COUNT               _BIT(GRP_IRQ_COUNT)
#define TAG_PCPU_STATUS             _BIT(GRP_PCPU_STATUS)
#define TAG_VCPU_SCHED_DELAY        _BIT(GRP_VCPU_SCHED_DELAY)
#define TAG_VCPU_EXEC_SPLIT         _BIT(GRP_VCPU_EXEC_SPLIT)
#define TAG_TOP                     _BIT(GRP_TOP)
#define TAG_IRQ_DELAY               _BIT(GRP_IRQ_DELAY)
#define TAG_CPU_IPI_DELAY           _BIT(GRP_CPU_IPI_DELAY)

// trace events
enum nt_events {
    EVT_VCPU_ENTER = 0,
    EVT_VCPU_EXIT,
    EVT_VCPU_INQUE,
    EVT_IRQ_ENTER,
    EVT_IRQ_INJECT,
    EVT_IPI_SEND,
    EVT_IPI_RECEIVED,
};

// trace id
#define TID_VCPU_EXEC_ENTER         NT_TAG(TAG_VCPU_EXEC, EVT_VCPU_ENTER)
#define TID_VCPU_EXEC_EXIT          NT_TAG(TAG_VCPU_EXEC, EVT_VCPU_EXIT)

#define TID_VCPU_RUN_ACCUM_ENTER    NT_TAG(TAG_VCPU_RUN_ACCUM, EVT_VCPU_ENTER)
#define TID_VCPU_RUN_ACCUM_EXIT     NT_TAG(TAG_VCPU_RUN_ACCUM, EVT_VCPU_EXIT)

#define TID_VCPU_EXIT_REASON        NT_TAG(TAG_VCPU_EXIT_REASON, 0)

#define TID_IRQ_COUNT               NT_TAG(TAG_IRQ_COUNT, 0)

#define TID_PCPU_ENTER_VCPU         NT_TAG(TAG_PCPU_STATUS, EVT_VCPU_ENTER)
#define TID_PCPU_EXIT_VCPU          NT_TAG(TAG_PCPU_STATUS, EVT_VCPU_EXIT)

#define TID_VCPU_SCHED_DELAY_INQUE  NT_TAG(TAG_VCPU_SCHED_DELAY, EVT_VCPU_INQUE)
#define TID_VCPU_SCHED_DELAY_RUN    NT_TAG(TAG_VCPU_SCHED_DELAY, EVT_VCPU_ENTER)

#define TID_VCPU_EXEC_SPLIT_ENTER   NT_TAG(TAG_VCPU_EXEC_SPLIT, EVT_VCPU_ENTER)
#define TID_VCPU_EXEC_SPLIT_EXIT    NT_TAG(TAG_VCPU_EXEC_SPLIT, EVT_VCPU_EXIT)

#define TID_IRQ_DELAY_ENTER         NT_TAG(TAG_IRQ_DELAY, EVT_IRQ_ENTER)
#define TID_IRQ_DELAY_INJECT        NT_TAG(TAG_IRQ_DELAY, EVT_IRQ_INJECT)

#define TID_IPI_DELAY_SEND         NT_TAG(TAG_CPU_IPI_DELAY, EVT_IPI_SEND)
#define TID_IPI_DELAY_RECEIVED     NT_TAG(TAG_CPU_IPI_DELAY, EVT_IPI_RECEIVED)

//////////////////
#define TRACER_NAME_LEN     32

#define NBL_TRACE_VCPU_CNT  8
#define NBL_TRACE_VM_CNT    2

#define NBL_TRACE_MAX_IRQS    1024

typedef struct {
    char name[TRACER_NAME_LEN];
    size_t buf_offs;
    size_t buf_size;
    int32_t err_code;
    bool supported;
} nbl_tracer_info_t;

/*
 * trace buffer layout:
 *  ---------------------------------------------------------------------------
 * | nbl_trace_header_t | padding | tracers[0] | tracers[1] | ... | tracers[N] |
 *  ---------------------------------------------------------------------------
 * | <-         buf_offs       -> |
 *                                | <-             N: tracer_cnt            -> |
 */
typedef struct {
#define NBL_TRACE_MAGIC  0x4e626c5472616365 // NblTrace
    uint64_t magic;
    size_t buf_offs;
    uint32_t version;
    uint32_t tracer_cnt;
    nbl_tracer_info_t tracers[GRP_TYPE_CNT];
} nbl_trace_header_t;

