// Copyright 2017 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <assert.h>

#include <zircon/compiler.h>
#include <zircon/types.h>

#ifdef __cplusplus
static constexpr uint16_t kMaxDumpBufferSize = 1024;
#endif

__BEGIN_CDECLS

// clang-format off
enum {
    ZX_GUEST_TRAP_BELL  = 0,
    ZX_GUEST_TRAP_MEM   = 1,
    ZX_GUEST_TRAP_IO    = 2,
};

enum {
    ZX_VCPU_STATE       = 0,
    ZX_VCPU_IO          = 1,
};
// clang-format on

// Structure to read and write VCPU state.
typedef struct zx_vcpu_state {
#if __aarch64__
    uint64_t x[31];
    uint64_t sp;
    // Contains only the user-controllable upper 4-bits (NZCV).
    uint32_t cpsr;
#elif __x86_64__
    uint64_t rax;
    uint64_t rcx;
    uint64_t rdx;
    uint64_t rbx;
    uint64_t rsp;
    uint64_t rbp;
    uint64_t rsi;
    uint64_t rdi;
    uint64_t r8;
    uint64_t r9;
    uint64_t r10;
    uint64_t r11;
    uint64_t r12;
    uint64_t r13;
    uint64_t r14;
    uint64_t r15;
    // Contains only the user-controllable lower 32-bits.
    uint64_t rflags;
#endif
} zx_vcpu_state_t;

// Structure to read and write VCPU state for IO ports.
typedef struct zx_vcpu_io {
    uint8_t access_size;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        uint8_t data[4];
    };
} zx_vcpu_io_t;

// Possible values for "bootmode" in zx_system_get_bootmode.
// should sync with 'enum bootmode_t'
typedef enum {
    ZX_BOOTMODE_PHYP,      // -x
    ZX_BOOTMODE_TEE,       // secure el1
    ZX_BOOTMODE_AHYP,      // -x -z
    ZX_BOOTMODE_QEMU_AHYP, // -x -y -C2
    ZX_BOOTMODE_OKL4_AHYP, // -x -y -C0  (ree cpu num==0)
} zx_bootmode_t;

enum {
    ZX_TEE_VENDOR_NONE = 0x0,
    ZX_TEE_VENDOR_NEBULA = 0x1,
    ZX_TEE_VENDOR_OPTEE = 0x2,
    ZX_TEE_VENDOR_TRUSTONIC = 0x3,
    ZX_TEE_VENDOR_MASK = 0x7F,
    ZX_TEE_VENDOR_UNKNOWN = 0xff,
};

struct irq_monitor_cfg {
    uint8_t enable;
    uint32_t irq_cnt_threshold;
    // irq bitmap, maximum irq cnt is 1024
    uint64_t irqs[16];
};

void irq_monitor_config(struct irq_monitor_cfg* cfg);

__END_CDECLS
