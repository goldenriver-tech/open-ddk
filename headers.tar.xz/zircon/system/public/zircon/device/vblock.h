#pragma once

#define VBLOCK_IPC_SHM_SVR_ID 0x0
#define VBLOCK_IPC_EVENT_SVR_ID0 0x10
#define VBLOCK_IPC_FIFO_SVR_ID0 0x20
#define VBLOCK_IPC_FIFO_SVR_ID1 0x21

#define RPC_QDEPTH_ORDER 8
#define FIFO_QDEPTH (1 << RPC_QDEPTH_ORDER)
#define RPC_Q_MEMORY (1 << 14)

enum {
  INTERRUPT,
  NOTIFY,
  EVENT_CNT,
};

struct mem_region {
  uint64_t start;
  uint64_t end;
};

static __attribute__((unused)) uint64_t
mem_region_size(struct mem_region const *mrg) {
  return mrg->end - mrg->start + 1;
}

struct start_param {
  uint16_t vmid;
  struct mem_region mem;
};

typedef struct get_handle_param {
  uint16_t vmid;
  uint16_t fifo_id;
} get_handle_param_t;

struct direct_io_rw_param {
uint32_t len;
uint64_t sector;
uint64_t addr;
};

struct fifo_in_item {
  uint64_t addr;
  uint32_t len;
  uint32_t head;
};

struct fifo_out_item {
  uint32_t head;
};
