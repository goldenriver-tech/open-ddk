// Copyright 2024 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <zircon/device/ioctl.h>
#include <zircon/device/ioctl-wrapper.h>
#include <zircon/types.h>

#define FRAMEBUFFER_DEV "/dev/sys/platform/ramfb/mtk_ramfb/framebuffer"
#define GRT_RAMFB_CONTROL_DEVICE "/dev/sys/platform/ramfb/mtk_ramfb"

#define IOCTL_GRT_RAMFB_RELEASE \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_RAMFB, 0)

#define IOCTL_GRT_RAMFB_GET_EVENT \
    IOCTL(IOCTL_KIND_GET_HANDLE, IOCTL_FAMILY_RAMFB, 1)

#define IOCTL_GRT_RAMFB_GET_VSYNC_EVENT \
    IOCTL(IOCTL_KIND_GET_HANDLE, IOCTL_FAMILY_RAMFB, 2)

#define IOCTL_GRT_RAMFB_SET_CLUSTER_HIDE \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_RAMFB, 3)

IOCTL_WRAPPER(ioctl_display_notify_ramfb, IOCTL_GRT_RAMFB_RELEASE);
IOCTL_WRAPPER_OUT(ioctl_grt_ramfb_get_event, IOCTL_GRT_RAMFB_GET_EVENT, zx_handle_t);
IOCTL_WRAPPER_OUT(ioctl_grt_ramfb_get_vsync_event, IOCTL_GRT_RAMFB_GET_VSYNC_EVENT, zx_handle_t);
IOCTL_WRAPPER_IN(ioctl_grt_ramfb_set_cluster_hide, IOCTL_GRT_RAMFB_SET_CLUSTER_HIDE, bool);