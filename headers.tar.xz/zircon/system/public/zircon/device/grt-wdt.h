// Copyright 2024 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <zircon/device/ioctl.h>
#include <zircon/device/ioctl-wrapper.h>
#include <zircon/types.h>


#define GRT_WDT_CONTROL_DEVICE "/dev/sys/platform/wdt/mtk_wdt"

#define IOCTL_GRT_WDT_START \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_WDT, 0)


#define IOCTL_GRT_WDT_STOP \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_WDT, 1)


#define IOCTL_GRT_WDT_PING \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_WDT, 2)


#define IOCTL_GRT_WDT_SET_TIMEOUT \
    IOCTL(IOCTL_KIND_SET_HANDLE, IOCTL_FAMILY_WDT, 3)


#define IOCTL_GRT_WDT_SET_RESTART \
    IOCTL(IOCTL_KIND_SET_HANDLE, IOCTL_FAMILY_WDT, 4)

#define IOCTL_GRT_WDT_INFO \
    IOCTL(IOCTL_KIND_SET_HANDLE, IOCTL_FAMILY_WDT, 5)

#define IOCTL_GRT_WDT_ACTIVE \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_WDT, 6)

#define IOCTL_GRT_SET_RST_WDT \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_WDT, 7)

#define IOCTL_GRT_SET_SUSPEND_WDT \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_WDT, 8)

#define IOCTL_GRT_SET_RESUME_WDT \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_WDT, 9)

typedef struct grt_wdt_ioctl_data {
    unsigned int timeout;
} grt_wdt_ioctl_data_t;


IOCTL_WRAPPER(ioctl_grt_wdt_start, IOCTL_GRT_WDT_START);
IOCTL_WRAPPER(ioctl_grt_wdt_stop, IOCTL_GRT_WDT_STOP);
IOCTL_WRAPPER(ioctl_grt_wdt_ping, IOCTL_GRT_WDT_PING);
IOCTL_WRAPPER(ioctl_grt_wdt_set_rst_status, IOCTL_GRT_SET_RST_WDT);
IOCTL_WRAPPER_IN(ioctl_grt_wdt_set_timeout, IOCTL_GRT_WDT_SET_TIMEOUT, uint32_t);
IOCTL_WRAPPER(ioctl_grt_wdt_restart, IOCTL_GRT_WDT_SET_RESTART);
IOCTL_WRAPPER_VARIN_OUT(ioctl_grt_wdt_info, IOCTL_GRT_WDT_INFO, void*, grt_wdt_ioctl_data_t);
IOCTL_WRAPPER(ioctl_grt_wdt_active, IOCTL_GRT_WDT_ACTIVE);
IOCTL_WRAPPER(ioctl_grt_wdt_set_suspend, IOCTL_GRT_SET_SUSPEND_WDT);
IOCTL_WRAPPER(ioctl_grt_wdt_set_resume, IOCTL_GRT_SET_RESUME_WDT);


