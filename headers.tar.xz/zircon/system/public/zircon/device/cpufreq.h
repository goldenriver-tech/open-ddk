// Copyright 2024 The GoldenRiverTek Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <string.h>

#include <zircon/types.h>

#include <zircon/device/ioctl.h>
#include <zircon/device/ioctl-wrapper.h>

// Enable nebula trace
#define IOCTL_CPUFREQ_TRACE_SET_BUF \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_CPUFREQ, 1)

static inline zx_status_t ioctl_cpufreq_trace_set_buf(int fd, uint64_t* data) {
    return fdio_ioctl(fd, IOCTL_CPUFREQ_TRACE_SET_BUF, data, sizeof(*data) * 2,
                      NULL, 0);
}
