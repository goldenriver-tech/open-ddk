// Copyright 2024 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <zircon/device/ioctl.h>
#include <zircon/device/ioctl-wrapper.h>
#include <zircon/types.h>

#define GRT_SPI_CONTROL_DEVICE "/dev/sys/platform/spi/mtk_spi"

#define IOCTL_GRT_SPI_CREATE_TRANSFER_HANDLES \
    IOCTL(IOCTL_KIND_SET_TWO_HANDLES, IOCTL_FAMILY_SPI, 0)

#define IOCTL_GRT_SPI_CLOSE_TRANSFER_HANDLES \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_SPI, 1)

#define IOCTL_GRT_SPI_TRIGGER_TRANSFER \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_SPI, 2)

#define IOCTL_GRT_SPI_GET_EVENT \
    IOCTL(IOCTL_KIND_GET_HANDLE, IOCTL_FAMILY_SPI, 3)

#define IOCTL_GRT_STOP_SPI_DMA_TRANSFER \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_SPI, 4)

typedef struct grt_spi_transfer {
    zx_handle_t tx_vmo;
    zx_handle_t rx_vmo;
    int size;
} grt_spi_transfer_t;

IOCTL_WRAPPER_IN(ioctl_grt_spi_create_transfer_handles, IOCTL_GRT_SPI_CREATE_TRANSFER_HANDLES, grt_spi_transfer_t);
IOCTL_WRAPPER(ioctl_grt_spi_close_transfer_handles, IOCTL_GRT_SPI_CLOSE_TRANSFER_HANDLES);
IOCTL_WRAPPER(ioctl_grt_spi_trigger_transfer, IOCTL_GRT_SPI_TRIGGER_TRANSFER);
IOCTL_WRAPPER_OUT(ioctl_grt_spi_get_event, IOCTL_GRT_SPI_GET_EVENT, zx_handle_t);
IOCTL_WRAPPER(ioctl_grt_stop_spi_dma_transfer, IOCTL_GRT_STOP_SPI_DMA_TRANSFER);