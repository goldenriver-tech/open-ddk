// Copyright 2026 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <zircon/device/ioctl.h>
#include <zircon/device/ioctl-wrapper.h>
#include <zircon/types.h>

#define GRT_EINT_DEVICE "/dev/sys/platform/mtk_eint"

#define IOCTL_GRT_EINT_IRQ_REQUEST \
    IOCTL(IOCTL_KIND_GET_HANDLE, IOCTL_FAMILY_GPIO, 10)

#define IOCTL_GRT_EINT_SET_TYPE \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_GPIO, 11)

#define IOCTL_GRT_EINT_MASK \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_GPIO, 12)

#define IOCTL_GRT_EINT_UNMASK \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_GPIO, 13)

#define IOCTL_GRT_EINT_ACK \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_GPIO, 14)

#define IOCTL_GRT_EINT_GET_MAX_EINT_NUM \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_GPIO, 15)

#define IOCTL_GRT_EINT_VM_DESTROY \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_GPIO, 16)

typedef struct pdev_eint_request {
    uint32_t eint_num;
    uint16_t vmid;
} pdev_eint_req_t;

typedef struct pdev_eint_set_type {
    uint32_t eint_num;
    uint32_t type;
} pdev_eint_set_type_t;

// Structure for EINT operations
typedef struct pdev_eint_op {
    uint32_t eint_num;
} pdev_eint_op_t;

// IOCTL wrapper functions
IOCTL_WRAPPER_INOUT(ioctl_grt_eint_irq_request, IOCTL_GRT_EINT_IRQ_REQUEST, pdev_eint_req_t, zx_handle_t);
IOCTL_WRAPPER_IN(ioctl_grt_eint_set_type, IOCTL_GRT_EINT_SET_TYPE, pdev_eint_set_type_t);
IOCTL_WRAPPER_IN(ioctl_grt_eint_mask, IOCTL_GRT_EINT_MASK, pdev_eint_op_t);
IOCTL_WRAPPER_IN(ioctl_grt_eint_unmask, IOCTL_GRT_EINT_UNMASK, pdev_eint_op_t);
IOCTL_WRAPPER_IN(ioctl_grt_eint_ack, IOCTL_GRT_EINT_ACK, pdev_eint_op_t);
IOCTL_WRAPPER_OUT(ioctl_grt_eint_get_max_eint_num, IOCTL_GRT_EINT_GET_MAX_EINT_NUM, uint32_t);
IOCTL_WRAPPER_IN(ioctl_grt_eint_vm_destroy, IOCTL_GRT_EINT_VM_DESTROY, uint16_t);
