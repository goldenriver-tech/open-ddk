// Copyright 2024 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <zircon/device/ioctl.h>
#include <zircon/device/ioctl-wrapper.h>
#include <zircon/types.h>


#define GRT_GPIO_CONTROL_DEVICE "/dev/sys/platform/gpio/mtk_gpio"

#define IOCTL_GRT_RELEASE_GPIO \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_GPIO, 0)

#define IOCTL_GRT_GET_GPIO_LEVEL \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_GPIO, 1)

#define IOCTL_GRT_GPIO_GET_EVENT \
    IOCTL(IOCTL_KIND_GET_HANDLE, IOCTL_FAMILY_GPIO, 2)

#define IOCTL_GRT_GPIO_ENABLE_IRQ \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_GPIO, 3)

IOCTL_WRAPPER(ioctl_grt_release_gpio, IOCTL_GRT_RELEASE_GPIO);
IOCTL_WRAPPER_INOUT(ioctl_grt_get_gpio_level, IOCTL_GRT_GET_GPIO_LEVEL, uint32_t, uint32_t);
IOCTL_WRAPPER_OUT(ioctl_grt_gpio_get_event, IOCTL_GRT_GPIO_GET_EVENT, zx_handle_t);
IOCTL_WRAPPER_IN(ioctl_grt_gpio_enable_irq, IOCTL_GRT_GPIO_ENABLE_IRQ, uint32_t);