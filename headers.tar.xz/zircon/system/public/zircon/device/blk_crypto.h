
#pragma once

#include <stdint.h>
#include <zircon/compiler.h>
#ifdef __cplusplus
#include <fbl/atomic.h>
#else
#include <stdatomic.h>
#endif
#include <zircon/listnode.h>
#include <zircon/device/block.h>
#include <threads.h>
#include <zircon/listnode.h>

#include "hash.h"

__BEGIN_CDECLS

typedef struct list_node list_head;

struct blk_crypto_config {
  enum blk_crypto_mode_num crypto_mode;
  unsigned int data_unit_size;
  unsigned int dun_bytes;
  enum blk_crypto_key_type key_type;
};

/*
 * Currently the maximum standard key size is 64 bytes, as that is the key size
 * of BLK_ENCRYPTION_MODE_AES_256_XTS which takes the longest key.
 *
 * The maximum hardware-wrapped key size depends on the hardware's key wrapping
 * algorithm, which is a hardware implementation detail, so it isn't precisely
 * specified.  But currently 128 bytes is plenty in practice.  Implementations
 * are recommended to wrap a 32-byte key for the hardware KDF with AES-256-GCM,
 * which should result in a size closer to 64 bytes than 128.
 *
 * Both of these values can trivially be increased if ever needed.
 */
#define BLK_CRYPTO_MAX_STANDARD_KEY_SIZE 64
#define BLK_CRYPTO_MAX_HW_WRAPPED_KEY_SIZE 128

#define BLK_CRYPTO_MAX_ANY_KEY_SIZE                                            \
  (BLK_CRYPTO_MAX_HW_WRAPPED_KEY_SIZE > BLK_CRYPTO_MAX_STANDARD_KEY_SIZE       \
       ? BLK_CRYPTO_MAX_HW_WRAPPED_KEY_SIZE                                    \
       : BLK_CRYPTO_MAX_STANDARD_KEY_SIZE)

struct blk_crypto_base_key {
  struct blk_crypto_config crypto_cfg;
  unsigned int data_unit_size_bits;
  unsigned int size;
  uint8_t raw[BLK_CRYPTO_MAX_ANY_KEY_SIZE];
};

struct blk_crypto_key {
  union {
    struct {
      struct blk_crypto_config crypto_cfg;
      unsigned int data_unit_size_bits;
      unsigned int size;
      uint8_t raw[BLK_CRYPTO_MAX_ANY_KEY_SIZE];
    };
    struct blk_crypto_base_key base_key;
  };
  uint8_t priv;
};

void blk_crypto_key_set_priv(struct blk_crypto_key *key, uint8_t priv);

struct blk_crypto_keyslot {
#ifdef __cplusplus
  fbl::atomic_int slot_refs;
#else
  atomic_int slot_refs;
#endif
  list_head idle_slot_node;
  struct hlist_node hash_node;
  const struct blk_crypto_key *key;
  struct blk_crypto_profile *profile;
};

#define BLK_CRYPTO_MAX_IV_SIZE 32
#define BLK_CRYPTO_DUN_ARRAY_SIZE (BLK_CRYPTO_MAX_IV_SIZE / sizeof(uint64_t))

struct bio_crypt_ctx {
  const struct blk_crypto_key *bc_key;
  uint64_t bc_dun[BLK_CRYPTO_DUN_ARRAY_SIZE];
  struct blk_crypto_keyslot *keyslot;
};

struct device;

struct blk_crypto_profile;

/**
 * struct blk_crypto_ll_ops - functions to control inline encryption hardware
 *
 * Low-level operations for controlling inline encryption hardware.  This
 * interface must be implemented by storage drivers that support inline
 * encryption.  All functions may sleep, are serialized by profile->lock, and
 * are never called while profile->dev (if set) is runtime-suspended.
 */
struct blk_crypto_ll_ops {

  /**
   * @keyslot_program: Program a key into the inline encryption hardware.
   *
   * Program @key into the specified @slot in the inline encryption
   * hardware, overwriting any key that the keyslot may already contain.
   * The keyslot is guaranteed to not be in-use by any I/O.
   *
   * This is required if the device has keyslots.  Otherwise (i.e. if the
   * device is a layered device, or if the device is real hardware that
   * simply doesn't have the concept of keyslots) it is never called.
   *
   * Must return 0 on success, or -errno on failure.
   */
  int (*keyslot_program)(struct blk_crypto_profile *profile,
                         const struct blk_crypto_key *key, unsigned int slot);

  /**
   * @keyslot_evict: Evict a key from the inline encryption hardware.
   *
   * If the device has keyslots, this function must evict the key from the
   * specified @slot.  The slot will contain @key, but there should be no
   * need for the @key argument to be used as @slot should be sufficient.
   * The keyslot is guaranteed to not be in-use by any I/O.
   *
   * If the device doesn't have keyslots itself, this function must evict
   * @key from any underlying devices.  @slot won't be valid in this case.
   *
   * If there are no keyslots and no underlying devices, this function
   * isn't required.
   *
   * Must return 0 on success, or -errno on failure.
   */
  int (*keyslot_evict)(struct blk_crypto_profile *profile,
                       const struct blk_crypto_key *key, unsigned int slot);
};

struct blk_crypto_profile_dev {
  /**
   * @ll_ops: Driver-provided functions to control the inline encryption
   * hardware, e.g. program and evict keys.
   */
  struct blk_crypto_ll_ops ll_ops;

  union {
    struct blk_crypto_cap caps;
    struct {
      /**
       * @max_dun_bytes_supported: The maximum number of bytes supported for
       * specifying the data unit number (DUN).  Specifically, the range of
       * supported DUNs is 0 through (1 << (8 * max_dun_bytes_supported)) - 1.
       */
      unsigned int max_dun_bytes_supported;

      /**
       * @key_types_supported: A bitmask of the supported key types:
       * BLK_CRYPTO_KEY_TYPE_STANDARD and/or BLK_CRYPTO_KEY_TYPE_HW_WRAPPED.
       */
      unsigned int key_types_supported;

      /**
       * @modes_supported: Array of bitmasks that specifies whether each
       * combination of crypto mode and data unit size is supported.
       * Specifically, the i'th bit of modes_supported[crypto_mode] is set if
       * crypto_mode can be used with a data unit size of (1 << i).  Note that
       * only data unit sizes that are powers of 2 can be supported.
       */
      unsigned int modes_supported[BLK_ENCRYPTION_MODE_MAX];
    };
  };

  /* Number of keyslots, or 0 if not applicable */
  uint8_t num_slots;
  /**
   * @dev: An optional device for runtime power management.  If the driver
   * provides this device, it will be runtime-resumed before any function
   * in @ll_ops is called and will remain resumed during the call.
   */
  struct device *dev;
};

__END_CDECLS
