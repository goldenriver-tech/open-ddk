
#pragma once

#define __always_inline __attribute__((always_inline)) inline

static __always_inline int fls(unsigned int x) {
  int r = 32;

  if (!x)
    return 0;
  if (!(x & 0xffff0000u)) {
    x <<= 16;
    r -= 16;
  }
  if (!(x & 0xff000000u)) {
    x <<= 8;
    r -= 8;
  }
  if (!(x & 0xf0000000u)) {
    x <<= 4;
    r -= 4;
  }
  if (!(x & 0xc0000000u)) {
    x <<= 2;
    r -= 2;
  }
  if (!(x & 0x80000000u)) {
    x <<= 1;
    r -= 1;
  }
  return r;
}

#undef BITS_PER_U64
#define BITS_PER_U64 (sizeof(uint64_t) * 8)

static __always_inline int fls64(uint64_t x) {
  int num = BITS_PER_U64 - 1;

  if (x == 0)
    return 0;

  if (!(x & (~0ull << (BITS_PER_U64 - 32)))) {
    num -= 32;
    x <<= 32;
  }
  if (!(x & (~0ull << (BITS_PER_U64 - 16)))) {
    num -= 16;
    x <<= 16;
  }
  if (!(x & (~0ull << (BITS_PER_U64 - 8)))) {
    num -= 8;
    x <<= 8;
  }
  if (!(x & (~0ull << (BITS_PER_U64 - 4)))) {
    num -= 4;
    x <<= 4;
  }
  if (!(x & (~0ull << (BITS_PER_U64 - 2)))) {
    num -= 2;
    x <<= 2;
  }
  if (!(x & (~0ull << (BITS_PER_U64 - 1))))
    num -= 1;

  return num + 1;
}

static inline unsigned fls_long(unsigned long l) { return fls64(l); }

static inline __attribute__((const)) unsigned long
__roundup_pow_of_two(unsigned long n) {
  return 1UL << fls_long(n - 1);
}

#define roundup_pow_of_two(n)                                                  \
  (__builtin_constant_p(n) ? (((n) == 1) ? 1 : (1UL << (ilog2((n)-1) + 1)))    \
                           : __roundup_pow_of_two(n))

static __always_inline __attribute__((const)) int __ilog2_uint64_t(uint64_t n) {
  return fls64(n) - 1;
}

static __always_inline __attribute__((const)) int __ilog2_uint32_t(uint32_t n) {
  return fls(n) - 1;
}

#define GOLDEN_RATIO_64 0x61C8864680B583EBull

static __always_inline uint32_t hash_64_generic(uint64_t val,
                                                unsigned int bits) {
  /* 64x64-bit multiply is efficient on all 64-bit processors */
  uint64_t const result = val * GOLDEN_RATIO_64 >> (64 - bits);
  return (uint32_t)result;
}

static inline uint32_t hash_ptr(const void *ptr, unsigned int bits) {
  return hash_64_generic((uint64_t)ptr, bits);
}

struct hlist_head {
  struct hlist_node *first;
};

struct hlist_node {
  struct hlist_node *next, **pprev;
};

#define INIT_HLIST_HEAD(ptr) ((ptr)->first = NULL)

#define __WRITE_ONCE(x, val)                                                   \
  do {                                                                         \
    x = (val);                                                                 \
  } while (0)

#define WRITE_ONCE(x, val)                                                     \
  do {                                                                         \
    __WRITE_ONCE(x, val);                                                      \
  } while (0)

static inline void __hlist_del(struct hlist_node *n) {
  struct hlist_node *next = n->next;
  struct hlist_node **pprev = n->pprev;

  WRITE_ONCE(*pprev, next);
  if (next)
    WRITE_ONCE(next->pprev, pprev);
}

static inline void hlist_del(struct hlist_node *h) {
  __hlist_del(h);
  h->next = NULL;
  h->pprev = NULL;
}

/**
 * hlist_add_head - add a new entry at the beginning of the hlist
 * @n: new entry to be added
 * @h: hlist head to add it after
 *
 * Insert a new entry after the specified head.
 * This is good for implementing stacks.
 */
static inline void hlist_add_head(struct hlist_node *n, struct hlist_head *h) {
  struct hlist_node *first = h->first;
  WRITE_ONCE(n->next, first);
  if (first)
    WRITE_ONCE(first->pprev, &n->next);
  WRITE_ONCE(h->first, n);
  WRITE_ONCE(n->pprev, &h->first);
}

#ifndef container_of
#define container_of(ptr, type, member)                                        \
  ({                                                                           \
    void *__ptr = (void *)(ptr);                                               \
    __ptr - offsetof(type, member);                                            \
  })
#endif

#define hlist_entry(ptr, type, member) container_of(ptr, type, member)

#define hlist_entry_safe(ptr, type, member)                                    \
  ({                                                                           \
    void *____ptr = (void *)(ptr);                                             \
    ____ptr ? hlist_entry(____ptr, type, member) : NULL;                       \
  })

/**
 * hlist_for_each_entry - iterate over list of given type
 * @type:	the type of *pos
 * @pos:        the type * to use as a loop cursor.
 * @head:       the head for your list.
 * @member:     the name of the hlist_node within the struct.
 */
#define hlist_for_each_entry(type, pos, head, member)                          \
  for (pos = hlist_entry_safe((head)->first, type, member); pos;               \
       pos = hlist_entry_safe((pos)->member.next, type, member))
