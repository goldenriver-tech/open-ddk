// Copyright 2024 The Fuchsia Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#pragma once

#include <zircon/device/ioctl.h>
#include <zircon/device/ioctl-wrapper.h>
#include <zircon/types.h>


#define GRT_MONITOR_CONTROL_DEVICE "/dev/sys/platform/monitor/mtk_monitor"

#define IOCTL_GRT_MONITOR_SEND_DATA \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_MONITOR, 0)

#define IOCTL_GRT_GET_MONITOR_EVENT \
    IOCTL(IOCTL_KIND_GET_HANDLE, IOCTL_FAMILY_MONITOR, 1)

#define IOCTL_GRT_ENABLE_MONITOR \
    IOCTL(IOCTL_KIND_DEFAULT, IOCTL_FAMILY_MONITOR, 2)

typedef struct grt_monitor_ioctl_data {
    unsigned long phy_addr;
    unsigned long size;
} grt_monitor_ioctl_data_t;

IOCTL_WRAPPER_IN(ioctl_grt_monitor_send_data, IOCTL_GRT_MONITOR_SEND_DATA, grt_monitor_ioctl_data_t);
IOCTL_WRAPPER_OUT(ioctl_grt_get_monitor_event, IOCTL_GRT_GET_MONITOR_EVENT, zx_handle_t);
IOCTL_WRAPPER_IN(ioctl_grt_enable_monitor, IOCTL_GRT_ENABLE_MONITOR, bool);